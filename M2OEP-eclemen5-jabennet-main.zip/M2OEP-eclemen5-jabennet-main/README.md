Created by Sydney M Clements and Jes Bennet
Our class will represent a calendar system that has different componet classes, and writes to a file for the password/username.
We use two has-a relations in the date class with the month and dayOfWeek classes
The calendar class has a date.
Later the functionality will include graphics for the calendar
Graphics on HTML
Interactable calendar through HTML
events/holidays on calendar


Bugs: Unsure as of right now
# Point breakdown 
* Main: 40 points has working input validation and username and password input to access dates
* Testing Program: 20 points Organized into functions and robust for each method
* Concept C++ Classes:
  * File output: 3 points Designed well but makes the file in cmake build
  * Date class: 20 has a day of week. Implemented robustly. Fully functional and designed well.
  * Date class: 20 has a month. Implemented robustly. Fully functional and designed well.
  * Calendar: 5 has a date. Implemented robustly. Fully functional and designed well.
* Style -0: i believe my style was good, the only issue would be switching between snake and camel case
* Video -0: I submitted it!
* Lifespan :( -0:
* Total: 108 points